from PIL import Image, ImageFont, ImageDraw
import datetime
import telebot
import random
import locale
import time
import os


menu = """
Для использование бота напишите: *чек | Имя получателя | номер получателя | сумма | имя отправителя* \n\n*Знак '|' НЕ ПИСАТЬ*\n\n*Скрины открывть с телефона !*\n*С компьютера могут быть проблемы шрифтом!*
\nДля баланса киви использовать: *киви тг/руб [баланс]*\n\nКонверт номера: *конверт номер*\nчтобы сделать из +77077070101 = *+7 (707) 707-01-01*

Создатель: @listenbyblik"""


file = open("api.txt")
api = file.read()

bot = telebot.TeleBot(api)

@bot.message_handler(command=['start'])
def start_message(message):
	bot.send_message(message.chat.id, f"""Привет, {message.from_user.username}
Для использование бота напишите: *чек Имя получателя / Номер получателя / Сумма / Имя отправителя* \n\n*ЗНАК '/' НЕ ПИСАТЬ!*""", parse_mode='Markdown')

@bot.message_handler(content_types=['text'])
def send_text(message):
	def msg(message_text):
		bot.send_message(message.chat.id, str(message_text))

	try:

		rub_qiwi = 'qiwi rub','qiwi руб','qiwi рубль','киви руб','киви рубль'
		tg_qiwi = 'киви tg','киви тг','киви тенге','qiwi тг','qiwi тенге','qiwi tg'


		if message.text.lower() == 'помощь':
			bot.send_message(message.chat.id, menu, parse_mode='Markdown')

		elif message.text.startswith('чек'):
			text = message.text.split()

			kvitance_numbers = '0123456789'
			for n in range(1):
				kvitance = ''

				for i in range(10):
					kvitance += random.choice(kvitance_numbers)

			current_time = datetime.datetime.now()
			current_time_string = current_time.strftime('%d.%m.%Y %H:%M')


			helvetica_font = 'fonts//helvetica_bold.otf'
			plumbkaz_regular_font = 'fonts//PlumbKaz-Regular.ttf'
			source_path = 'Image source//image_source.png'
			iphone_time = 'fonts//SF-Pro-Text-Bold.otf'

			to_input = text[1]
			mobilenumber = text[2]
			#inp_balance = text[3]
			from_input = text[4]

			clone_text = text[:]
			clone_text = [int(x) if x.lstrip('-').isdecimal() else x for x in clone_text]

			new_balance = clone_text[3]
			new = "{:,d}".format(new_balance).replace(',', ' ')
			str(new)

			balance = new + ' ₸'


			kaspi = Image.open(source_path)
			font = ImageFont.truetype(helvetica_font, 87)
			W = 828
			w, h = font.getsize(balance)
			d = ImageDraw.Draw(kaspi)
			d.text((150,715), balance, font=font, fill=(255,255,255,255))

			font = ImageFont.truetype(plumbkaz_regular_font, 30)
			d.text((260,540), to_input, font=font, fill=(105,105,105,105)) # Получатель
			d.text((260,580), mobilenumber, font=font, fill=(105,105,105,105)) # Номер

			font = ImageFont.truetype(plumbkaz_regular_font, 24)
			d.text((546,864), kvitance, font=font, fill=(0,0,0,0)) # Квитанция
			d.text((496,936), current_time_string, font=font, fill=(0,0,0,0)) # Время
			d.text((540,1084), from_input, font=font, fill=(0,0,0,0)) # Имя отправитля

			kaspi.save('kaspi_output.png', 'PNG')

			'''-------transfer check-------'''

			current_time = datetime.datetime.now()
			current_time_string = current_time.strftime('%H:%M')

			source_path_transfer = 'Image source//kaspi_put.png'

			kaspi = Image.open(source_path_transfer)
			font = ImageFont.truetype(helvetica_font, 90)
			w, h = font.getsize(balance)
			d = ImageDraw.Draw(kaspi)

			clone_text = text[:]
			clone_text = [int(x) if x.lstrip('-').isdecimal() else x for x in clone_text]

			new_balance = clone_text[3]
			new = "{:,d}".format(new_balance).replace(',', ' ')
			str(new)

			balance = new + ' ₸'

			d.text((30,300), balance, font=font, fill=(255,255,255,255)) # Сумма

			font = ImageFont.truetype(plumbkaz_regular_font, 35)
			d.text((30,640), to_input, font=font, fill=(105,105,105,105)) # Имя

			font = ImageFont.truetype(iphone_time, 30)
			d.text((60,30), current_time_string, font=font, fill=(105,105,105,105)) # Время

			kaspi.save('kaspi_transfer_output.png', 'PNG')

			bot.send_document(message.chat.id, open('kaspi_output.png', 'rb'))
			bot.send_document(message.chat.id, open('kaspi_transfer_output.png', 'rb'))

		elif message.text.startswith(rub_qiwi):
			balance = message.text.split()[2] + ' ₽'

			# Генерация самого фейк скрин скрина
			source_path = 'Image source//qiwi_balance.png'
			robotobold_path = 'fonts//Roboto-Bold.ttf'

			qiwi = Image.open(source_path)
			font = ImageFont.truetype(robotobold_path, 100)
			W = 1080
			w, h = font.getsize(balance)
			d = ImageDraw.Draw(qiwi)
			d.text(((W-w)/2,296), balance, font=font, fill=(255,255,255,255))

			qiwi.save('rub_qiwi_output.png', 'PNG')

			bot.send_document(message.chat.id, open('rub_qiwi_output.png', 'rb'))


		elif message.text.startswith(tg_qiwi):
			balance = message.text.split()[2] + ' ₸'

			# Генерация самого фейк скрин скрина
			source_path = 'Image source//qiwi_balance.png'
			helvetica_font = 'fonts//helvetica_bold.otf'

			qiwi = Image.open(source_path)
			font = ImageFont.truetype(helvetica_font, 100)
			W = 1080
			w, h = font.getsize(balance)
			d = ImageDraw.Draw(qiwi)
			d.text(((W-w)/2,296), balance, font=font, fill=(255,255,255,255))

			qiwi.save('tg_qiwi_output.png', 'PNG')

			bot.send_document(message.chat.id, open('tg_qiwi_output.png', 'rb'))

		elif message.text.startswith('конверт'):
			text = message.text.split()

			number = text[1]

			length = len(number)

			if length == 12:
				new = list(number)

				number_convert = f'{new[0]}{new[1]} ({new[2]}{new[3]}{new[4]}) {new[5]}{new[6]}{new[7]}-{new[8]}{new[9]}-{new[10]}{new[11]}'
				bot.send_message(message.chat.id, number_convert)

			elif '+' not in number and length == 11 and number.startswith('77'):
				new = list(number)
				new = ['+'] + new

				number_convert = f'{new[0]}{new[1]} ({new[2]}{new[3]}{new[4]}) {new[5]}{new[6]}{new[7]}-{new[8]}{new[9]}-{new[10]}{new[11]}'
				bot.send_message(message.chat.id, number_convert)
			else:
				bot.send_message(message.chat.id,'Длина номера не ровно = 12\nИли неправильно написали номер!\n\n*Пример: 77017070101 или +77017070101*', parse_mode='Markdown')

		else:
			bot.send_message(message.chat.id, 'Я не знаю такой команды.\n\n*Напишите "помощь" для просмотра моих команд.*', parse_mode='Markdown')

	except Exception as e:
		bot.send_message(message.chat.id,f'ОШИБКА! \n{e}')

bot.polling()